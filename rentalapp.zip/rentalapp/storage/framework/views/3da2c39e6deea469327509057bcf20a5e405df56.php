<?php $__env->startSection('content'); ?>
    <?php 
        if(Auth::user()->Roles == 1){
          $delete_url_path = '/admin/delete_role';
        }
        elseif(Auth::user()->Roles == 2){
          $delete_url_path = '/admin/company/delete_role';
        }
        else{
          $delete_url_path = '/admin/company/delete_role';
        }
     ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><?php echo e(trans('labels.home')); ?></li>
        <li class="breadcrumb-item"><a href="#"><?php echo e(trans('labels.admin')); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(trans('labels.admin')); ?> Roles List</li>
        <!-- Breadcrumb Menu-->
        <li class="breadcrumb-menu d-md-down-none">
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn" href="<?php echo e(url('admin/company/roles_list')); ?>"><i class="icon-graph"></i> &nbsp;Roles List</a>
            </div>
        </li>
    </ol>
    <div class="container-fluid">
        <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> <?php echo e(trans('labels.roles_list')); ?>

                    </div>
                    <div class="card-body">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                <table class="table table-responsive-sm table-bordered table-striped table-sm">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(trans('labels.name')); ?></th>
                                        <th><?php echo e(trans('labels.created_at')); ?></th>
                                        <th><?php echo e(trans('labels.action')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($role['id']); ?></td>
                                            <td>
                                                <?php echo e(ucwords($role['name'])); ?>

                                            </td>
                                            <td><?php echo GeneralFunctions::convertToDateTimeToString($role['created_at']); ?></td>
                                            <td>
                                                <?php 
                                                    if(Auth::user()->Roles == 1){
                                                      $edit_url_path = '/admin/roles_form?id='.GeneralFunctions::encryptString($role['id']);
                                                    }
                                                    elseif(Auth::user()->Roles == 2){
                                                      $edit_url_path = '/admin/company/roles_form?id='.GeneralFunctions::encryptString($role['id']);
                                                    }
                                                    else{
                                                      $edit_url_path = '/admin/partners/roles_form?id='.GeneralFunctions::encryptString($role['id']);
                                                    }
                                                 ?>
                                                <div class="btn-group" role="group">
                                                    <button id="btnGroupDrop1" type="button" class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        Action
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                                        <?php if(\App\Helpers\GeneralFunctions::check_edit_permission('edit.role')): ?>
                                                            <a href="<?php echo e(url($edit_url_path)); ?>" class="dropdown-item"><i class="fa fa-edit"></i>&nbsp; <?php echo e(trans('labels.edit')); ?></a>
                                                        <?php endif; ?>
                                                        <?php if(\App\Helpers\GeneralFunctions::check_delete_permission('edit.role')): ?>
                                                            <a href="javascript:void(0)" id="<?php echo e($role['id']); ?>" class="dropdown-item delete_btn"><i class="fa fa-trash"></i>&nbsp; <?php echo e(trans('labels.delete')); ?></a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="remodal" data-remodal-id="delete_modal" data-remodal-options="hashTracking: false, closeOnOutsideClick: false">
        <button data-remodal-action="close" class="remodal-close"></button>
        <h1><?php echo e(trans('labels.remove_role')); ?></h1>
        <p>
            <?php echo e(trans('labels.a.y.s.y.w.t.d.t.r')); ?>

        </p>
        <form id="delete_form" action="<?php echo e(url($delete_url_path)); ?>" method="POST">
            <input type="hidden" name="record_uuid" id="remodal_record_uuid">
            <?php echo e(csrf_field()); ?>

        </form>
        <br>
        <button data-remodal-action="cancel" class="remodal-cancel">Cancel</button>
        <button data-remodal-action="confirm" class="remodal-confirm">OK</button>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var record_uuid;
            $(document).on('click', '.delete_btn', function(){
                record_uuid = $(this).attr('id');
                $('#remodal_record_uuid').val(record_uuid);
                var inst = $('[data-remodal-id=delete_modal]').remodal();
                inst.open();
            });
            $(document).on('confirmation', '.remodal', function () {
                $('#delete_form').submit()[0];
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make( Auth::user()->Roles == 2 ? 'company_portal.layouts.app' :  (Auth::user()->Roles == 1 ? 'super_admin_portal.layouts.app' : 'partners_portal.layouts.app'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>