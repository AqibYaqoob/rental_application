<?php if(count($errors) > 0): ?>
    <div class="col-sm-12">
        <div class="alert alert-danger alert-list">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>
<?php if(\Session::has('status')): ?>
    <div class="col-sm-12">
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <p><?php echo e(\Session::get('status')); ?></p>
        </div>
    </div>
<?php endif; ?>
<?php if(\Session::has('success')): ?>
    <div class="col-sm-12">
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <p><?php echo e(\Session::get('success')); ?></p>
        </div>
    </div>
<?php endif; ?>
<?php if(\Session::has('error_msg')): ?>
    <div class="col-sm-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <p><?php echo e(\Session::get('error_msg')); ?></p>
        </div>
    </div>
<?php endif; ?>
<?php if(\Illuminate\Support\Facades\Session::has('errors_array')): ?>
    <div class="col-sm-12">
        <div class="alert alert-danger">
            <?php $__currentLoopData = session('errors_array'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="msg-box alert" style="display: none; width: 100%;">
    <ul style="text-decoration: none;" id="msg-list">

    </ul>
</div>
