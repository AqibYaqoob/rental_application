<?php $__env->startSection('content'); ?>
  <?php 
    $counter = 1;
    if(Auth::user()->Roles == 1){
        $url = '/admin/staff/roles';
        $delete_url_path = '/admin/delete_staff/';
    }
    else if(Auth::user()->Roles == 2){
        $url = '/admin/company/staff/roles';
        $delete_url_path = '/admin/company/delete_staff/';
    }
    else{
        $url = '/admin/company/staff/roles';
    }
   ?>
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item"><a href="#">Admin</a></li>
    <li class="breadcrumb-item active">Staff List</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
        <a class="btn" href="<?php echo e(url('admin/company/staff/member/list')); ?>"><i class="icon-graph"></i> &nbsp;Staff List</a>
      </div>
    </li>
  </ol>
  <!-- Main Content of the Page -->
  <div class="container-fluid">
    <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <i class="fa fa-align-justify"></i> <?php echo e(trans('labels.staff_list')); ?>

          </div>
          <div class="card-body">
            <table class="table table-responsive-sm table-bordered table-striped table-sm">
              <thead>
              <tr>
                <th>#</th>
                <th><?php echo e(trans('labels.username')); ?></th>
                <th><?php echo e(trans('labels.full_name')); ?></th>
                <th><?php echo e(trans('labels.date_registered')); ?></th>
                <th><?php echo e(trans('labels.role_description')); ?></th>
                <th><?php echo e(trans('labels.status')); ?></th>
                <th><?php echo e(trans('labels.action')); ?></th>
              </tr>
              </thead>
              <tbody>
              <?php if(isset($staff) && count($staff)>0): ?>
                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($counter); ?></td>
                    <td><?php echo e($member['Username']); ?></td>
                    <td>
                      <?php echo e(ucwords($member['staff_members']['staff_name'])); ?>

                    </td>
                    <td><?php echo GeneralFunctions::convertToDateTimeToString($member['created_at']); ?></td>
                    <td>
                      <?php echo e(ucwords($member['staff_members']['user_roles']['description'])); ?>

                    </td>
                    <td>
                      <?php if($member['AccountStatus'] == 0): ?>
                        <span class="badge badge-danger"><?php echo e(trans('labels.inactive')); ?></span>
                      <?php else: ?>
                        <span class="badge badge-success"><?php echo e(trans('labels.active')); ?></span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php 
                        if(Auth::user()->Roles == 1){
                            $edit_url_path = '/admin/staff/form?id='.GeneralFunctions::encryptString($member['id']);
                        }
                        elseif(Auth::user()->role_id == 2){
                            $edit_url_path = '/admin/company/staff/form?id='.GeneralFunctions::encryptString($member['id']);
                        }
                        else{
                            $edit_url_path = '/admin/company/staff/form?id='.GeneralFunctions::encryptString($member['id']);
                        }
                       ?>
                      <div class="btn-group" role="group">
                        <button id="btnGroupDrop1" type="button" class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <?php echo e(trans('labels.action')); ?>

                        </button>
                        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                          <a href="<?php echo e(url($edit_url_path)); ?>" class="dropdown-item"><i class="fa fa-edit"></i>&nbsp; <?php echo e(trans('labels.edit')); ?></a>
                          <a href="javascript:void(0)" id="<?php echo e($member['id']); ?>" class="dropdown-item delete_btn"><i class="fa fa-trash"></i>&nbsp; <?php echo e(trans('labels.delete')); ?></a>
                        </div>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!--/.col-->
    </div>
  </div>
  <!-- Popup For Deletion -->
  <div class="remodal" data-remodal-id="delete_modal" data-remodal-options="hashTracking: false, closeOnOutsideClick: false">
    <button data-remodal-action="close" class="remodal-close"></button>
    <h1><?php echo e(trans('labels.alert_info_box')); ?></h1>
    <p>
      <?php echo e(trans('labels.a.y.s.y.w.t.d.t.r')); ?>

    </p>
    <form id="delete_form" action="<?php echo e(url($delete_url_path)); ?>" method="POST">
      <input type="hidden" name="record_uuid" id="remodal_record_uuid">
      <?php echo e(csrf_field()); ?>

    </form>
    <br>
    <button data-remodal-action="cancel" class="remodal-cancel"><?php echo e(trans('labels.cancel')); ?></button>
    <button data-remodal-action="confirm" class="remodal-confirm"><?php echo e(trans('labels.ok')); ?></button>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
      $(document).ready(function(){
          var record_uuid;
          $(document).on('click', '.delete_btn', function(){
              record_uuid = $(this).attr('id');
              $('#remodal_record_uuid').val(record_uuid);
              var inst = $('[data-remodal-id=delete_modal]').remodal();
              inst.open();
          });
          $(document).on('confirmation', '.remodal', function () {
              $('#delete_form').submit()[0];
          });
      });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make( Auth::user()->Roles == 2 ? 'company_portal.layouts.app' :  (Auth::user()->Roles == 1 ? 'super_admin_portal.layouts.app' : 'partners_portal.layouts.app'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>