<?php $__env->startSection('content'); ?>
    <?php 
      $payment_name = null;
      $description = null;
        if(isset($payments_details)){
            $payment_name = $packages_details['payment_name'];
            $description = $packages_details['description'];
        }
     ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><?php echo e(trans('labels.dashboard')); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(trans('labels.payments')); ?></li>
    </ol>

    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <i class="fa fa-align-justify"></i> <?php echo e(trans('labels.payments')); ?>

                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/admin/payments/save/record')); ?>" method="post"
                              class="form-horizontal payments_save_form">
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="payment_name"><?php echo e(trans('labels.payment_name')); ?></label>
                                <div class="col-md-9">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="id" value="<?php echo e(Request::input('id')); ?>">
                                    <input type="text" id="payment_name" name="payment_name" class="form-control payment_name" placeholder="Payment Name" value="<?php echo e($payment_name); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label" for="description"><?php echo e(trans('labels.description')); ?></label>
                                <div class="col-md-9">
                                     <textarea id="description" name="description" class="form-control description"><?php echo e($description); ?></textarea>
                                </div>
                            </div>
                        </form>
                        <div class="col-lg-6 offset-6">
                            <?php if(GeneralFunctions::check_add_permission('payments_form') || GeneralFunctions::check_edit_permission('payments_form')): ?>
                                <img src="<?php echo e(url('img/loading.gif')); ?>" class="loading_gif" style="height: 26px !important; display: none;">
                                <a href="javascript:void(0)" class="btn btn-primary save_record"><?php echo e(trans('labels.save')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $(document).on('click', '.save_record', function () {
                $('.loading_gif').show();
                var data = $('.payments_save_form').serialize();
                var list = '';
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('/admin/payments/record/validation')); ?>",
                    data: data,
                    success: function (data) {
                        if (data.status == 'success') {
                            $('.payments_save_form').submit()[0];
                        }
                        else {
                            var errorArray = data.msg_data;
                            errorArray.forEach(function (e) {
                                list = list + '<li>' + e + '</li>';
                            });

                            $('#msg-list').html(list);
                            $('.msg-box').addClass("alert-danger").show();
                        }
                        $("html, .container").animate({scrollTop: 0}, 600);
                        $('.loading_gif').hide();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('super_admin_portal.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>