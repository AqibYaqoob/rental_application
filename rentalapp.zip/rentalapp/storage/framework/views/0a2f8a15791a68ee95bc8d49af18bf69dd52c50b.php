<?php $__env->startSection('content'); ?>
  <!-- Main Content of the Page -->
  <div class="container-fluid">
    <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> Form to fill with New Password
            </div>
            <div class="card-body">
              <?php if($status): ?>
                <form action="<?php echo e(url('/new/password/save/record')); ?>" method="post"
                              class="form-horizontal">
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="password">Password</label>
                        <div class="col-md-9">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e(GeneralFunctions::encryptString($userId)); ?>">
                            <input type="password" id="password" name="password" class="form-control password" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label" for="password_confirmation">Confirm Password</label>
                        <div class="col-md-9">
                            <input type="password" id="password_confirmation" name="password_confirmation" class="form-control password_confirmation" placeholder="Confirm Password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-9">
                            <button class="btn btn-success" type="submit">Save</button>
                        </div>
                    </div>
                </form>
              <?php else: ?>
                <div class="col-sm-12">
                    <div class="alert alert-danger">
                        <p>You did not provided the valid emil.</p>
                    </div>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <!--/.col-->
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
    $(document).ready(function(){
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom_layouts.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>