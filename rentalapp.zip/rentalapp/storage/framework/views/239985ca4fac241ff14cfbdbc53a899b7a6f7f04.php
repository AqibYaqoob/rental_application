<?php $__env->startSection('content'); ?>
  <ol class="breadcrumb">
      <li class="breadcrumb-item"><?php echo e(trans('labels.home')); ?></li>
      <li class="breadcrumb-item"><a href="#"><?php echo e(trans('labels.super_admin')); ?></a></li>
      <li class="breadcrumb-item active"><?php echo e(trans('labels.dashboard')); ?></li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu d-md-down-none">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn" href="<?php echo e(url('admin/company/dashboard')); ?>"><i class="icon-graph"></i> &nbsp;<?php echo e(trans('labels.dashboard')); ?></a>
        </div>
      </li>
   </ol>
     <!-- Main Content of the Page -->
     <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <div class="container-fluid">
       <div class="row">
              <div class="col-md-3">
                  <div class="card">
                      <div class="card-body">
                          <div class="d-flex">
                              <span class="align-self-center p-3 m-top-7">
                                  <i class="fa fa-handshake-o fa-3x"></i>
                              </span>
                              <div class="align-self-center">
                                  <h6 class="text-muted m-t-10 m-b-0">Active Total Staff Members</h6>
                                  <h2 class="m-t-0"><?php echo count($active_staff_members); ?></h2>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
       </div>
       <div class="animated fadeIn">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-align-justify"></i>
                            List of Active Land Loards
                        </div>
                        <div class="card-body">
                            <table class="table table-responsive-sm table-bordered table-striped table-sm">
                                <thead>
                                <tr>
                                  <th>Details</th>
                                  <th>User Name</th>
                                  <th>Full Name</th>
                                  <th>Date registered</th>
                                  <th>Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $ownersRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   <?php 
                                      $url = '/admin/user_details?id='.GeneralFunctions::encryptString($value['id']);
                                     ?>
                                    <td><a href="<?php echo e(url($url)); ?>"><i class="fa fa-info"></i> Details</a></td>
                                    <td><?php echo e($value['Username']); ?></td>
                                    <td><?php echo e($value['name']); ?></td>
                                    <td><?php echo GeneralFunctions::convertToDateTimeToString($value['created_at']); ?></td>
                                    <td><?php echo e($value['email']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-align-justify"></i>
                            List of Active Contractors
                        </div>
                        <div class="card-body">
                            <table class="table table-responsive-sm table-bordered table-striped table-sm">
                                <thead>
                                <tr>
                                  <th>Details</th>
                                  <th>User Name</th>
                                  <th>Full Name</th>
                                  <th>Date registered</th>
                                  <th>Email</th>
                                </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $contractorRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php 
                                      $url = '/admin/user_details?id='.GeneralFunctions::encryptString($value['id']);
                                     ?>
                                    <td><a href="<?php echo e(url($url)); ?>"><i class="fa fa-info"></i> Details</a></td>
                                    <td><?php echo e($value['Username']); ?></td>
                                    <td><?php echo e($value['name']); ?></td>
                                    <td><?php echo GeneralFunctions::convertToDateTimeToString($value['created_at']); ?></td>
                                    <td><?php echo e($value['email']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
     </div>
     
    <div class="remodal" data-remodal-id="delete_modal" data-remodal-options="hashTracking: false, closeOnOutsideClick: false">
        <button data-remodal-action="close" class="remodal-close"></button>
        <h1 class="status_title"></h1>

        <form id="state_form" action="<?php echo e(url('admin/update/account/status')); ?>" method="POST">
            <input type="hidden" class="record_id" name="id" />
            <input type="hidden" id="state" name="state" value="" />
            <?php echo e(csrf_field()); ?>

            <textarea style="display: none;" id="reason" name="reason" class="form-control reason" placeholder="Write a Reason" required></textarea>
            <div class="approve_account_details" style="display: none;">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="account_type" value="1">Free Account
                </label>
              </div>
              <div class="form-check">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="account_type" value="2">Paid Account
                </label>
              </div>
            </div>
        </form>
        <br>
        <button data-remodal-action="cancel" class="remodal-cancel">Cancel</button>
        <button data-remodal-action="confirm" class="remodal-confirm">OK</button>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $(document).on('click', '.account_status', function(){
                var state = $(this).attr('data-state');
                $('#state').val(state);
                $('.reason').show();
                $('.record_id').val($(this).attr('id'));
                if(state == 1)
                {
                  $('.status_title').text('Approve Account');
                  $('.approve_account_details').show();
                  $('.reason').hide();
                    // $('[data-remodal-action=confirm]').text('Activate');
                }
                else{
                  $('.status_title').text('Reject Account');
                  $('.approve_account_details').hide();
                  $('.reason').show();
                }
                var inst = $('[data-remodal-id=delete_modal]').remodal();
                inst.open();
            });
            $(document).on('confirmation', '.remodal', function () {
                $('#state_form').submit()[0];
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('super_admin_portal.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>