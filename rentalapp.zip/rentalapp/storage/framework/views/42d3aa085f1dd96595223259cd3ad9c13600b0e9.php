<?php $__env->startSection('content'); ?>
<?php 
  $selectedTimeZone = '';
  if(isset($tenant_setting_details) && count($tenant_setting_details) > 0){
    $selectedTimeZone = $tenant_setting_details['ValueData'];
  }

  if(Auth::user()->Roles == 1){
    $tenantSettingsUrl = '/admin/settings/update';
    $currentUrl = '/admin/settings';
  }
  elseif(Auth::user()->Roles == 2){
    $tenantSettingsUrl = '/admin/company/settings/update';
    $currentUrl = '/admin/company/settings';
  }else{
    $tenantSettingsUrl = '/admin/partner/settings/update';
    $currentUrl = '/admin/partner/settings';
  }
 ?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item"><a href="#">Admin</a></li>
    <li class="breadcrumb-item active">Setting</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
        <a class="btn" href="<?php echo e(url($currentUrl)); ?>"><i class="icon-graph"></i> &nbsp;Setting</a>
      </div>
    </li>
</ol>

<div class="container-fluid">
  <div class="row">
    <?php echo $__env->make('errors.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(\Session::has('error')): ?>
    <div class="col-sm-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <p><?php echo e(\Session::get('error')); ?></p>
        </div>
    </div>
  <?php endif; ?>
  </div>
  <div class="row">
      <div class="col-lg-6">
        <div class="card">
          <div class="card-header">
            <i class="fa fa-align-justify"></i> System Settings
          </div>
          <div class="card-body">
            <div class="card">
              <div class="card-header">
              </div>
              <div class="card-body">
                <form action="<?php echo e(url($tenantSettingsUrl)); ?>" method="post" class="form-horizontal contact_info_form">
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="p-full_name">System Time Zone</label>
                      <div class="col-md-9">
                        <?php echo e(csrf_field()); ?>

                        <select class="form-control" name="system_time_zone" id="system_time_zone">
                          <option value="">Choose Time Zone For the System</option>
                          <?php $__currentLoopData = (array) Config::get('constant.time_zone_dropdwn'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo $selectedTimeZone == $key ? 'selected' : ''; ?>><?php echo e($value); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row">
                      <label class="col-md-3 col-form-label" for="p-mobile_number">Mobile Number</label>
                      <div class="col-md-9">
                        <button class="btn btn-primary" type="submit">Submit</button>
                      </div>
                    </div>
                </form>
              </div>
            <div class="card-footer">
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php if(Auth::user()->Roles != 1): ?>
      <div class="col-md-6">
          <div class="card">
              <div class="card-header">
                  <i class="fa fa-align-justify"></i>
                  Currency Chart
              </div>
              <div class="card-body">
                  <form action="<?php echo e(route('update.currencies.tenant')); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                      <input type="hidden" id="baseCurrency" name="baseCurrency" value="" />
                      <div class="row" style="margin-bottom: 25px">
                          <div class="col-md-3">Currency Name</div>
                          <div class="col-md-6 text-center">Rate</div>
                          <div class="col-md-3">
                              Base Currency
                          </div>
                      </div>
                      <?php  $flage = false;  ?>
                      <?php $__currentLoopData = (array)$currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($currency->isBaseCurrency == 1): ?>
                              <?php  $flage = true;  ?>
                          <?php endif; ?>
                      <div class="row form-group">
                          <div class="col-md-2"><?php echo e($currency->currencyList->currency); ?></div>
                          <div class="col-md-8">
                              <input type="number" step="any" name="currency[<?php echo e($currency->Id); ?>]" value="<?php echo e($currency->CurrentRate); ?>" class="form-control" />
                          </div>
                          <div class="col-md-2">
                              <input class="base" type="radio" name="isBase" value="<?php echo e($currency->Id); ?>" <?php echo e(($currency->isBaseCurrency == 1) ? 'checked' : ''); ?> <?php echo e(($currency->isBaseCurrency != 1 && $flage == true) ? 'disabled' : ''); ?> />
                          </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php if($currencies->count() > 0): ?>
                          <div class="col-md-9 offset-2 text-center">
                              <button type="submit" class="btn btn-primary btn-md">Update</button>
                          </div>
                      <?php endif; ?>
                  </form>
              </div>
          </div>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $('.base').on('change',function (e) {
                console.log($(this).val());
                $('#baseCurrency').val($(this).val());
            });
        });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make( Auth::user()->Roles == 2 ? 'company_portal.layouts.app' :  (Auth::user()->Roles == 1 ? 'super_admin_portal.layouts.app' : 'partner_portal.layout.app'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>